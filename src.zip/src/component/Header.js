import React from 'react';
import icon from '../img/Union 1.png';
import image from '../img/Rectangle 3.png';
import '../css/Header.css';
import One from './One';

export default function Header() {
  return (
    <> 
    <div className='HeaderA'>
        <div className='HeaderAa'> 
      <h1>ATG.W<img src={icon} alt='o'/>RLD</h1>
      </div>

      <div className='HeaderAaa'>
      <form className="d-flex" role="search">
        <input className="form-control me-2" type="search" aria-label="Search" placeholder='Search for your favorite group in ATG' />
      </form>
      </div>

<div className='HeaderAaaa'> 
      <button type="button" className="btn btn-light">Create account</button>
      <div className="dropdown">
  <a className="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
    It's free!
  </a>

  <ul className="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <li><a className="dropdown-item" href="#">Action</a></li>
    <li><a className="dropdown-item" href="#">Another action</a></li>
    <li><a className="dropdown-item" href="#">Something else here</a></li>
  </ul>
</div>
    </div>
    </div>

<div className='HeaderB'>
<img src={image} alt='' id='HeaderBimg'/>
<div className='HeaderBb'>
    <h2>Computer Engineering</h2>
    <p>142,765 Cmputer Engineering follow this</p>
</div>

</div>



<div className='Mobile'>
  <One/>
</div>


    </>
  )
}
