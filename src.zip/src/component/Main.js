import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import One from './One';
import Two from './Two';
import Three from './Three';
import Four from './Four';
import Five from './Five';




function TabPanel(props) {
    const { children, value, index, ...other } = props;
  
    return (
    
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
        
      >
        {value === index && (
          <Box sx={{ p: 3 }}>
            <Typography className='MainMain'>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }
  
  TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
  };
  
  function a11yProps(index) {
    return {
      id: `simple-tab-${index}`,
      'aria-controls': `simple-tabpanel-${index}`,
    };
  }


export default function Main() {

    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
      setValue(newValue);
    };


  return (
    <> 
    <div style={{border:'2px solid black', display:'flex'}}> 
    <div className='MainMain'>
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
          <Tab label="All Post(32)" {...a11yProps(0)} />
          <Tab label="Article" {...a11yProps(1)} />
          <Tab label="Event" {...a11yProps(2)} />
          <Tab label="Education" {...a11yProps(3)} />
          <Tab label="Job" {...a11yProps(4)} />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        Item One
        <One/>
      </TabPanel>
      <TabPanel value={value} index={1}>
        Item Two
        <Two/>
      </TabPanel>
      <TabPanel value={value} index={2}>
        Item Three
        <Three/>
      </TabPanel>
      <TabPanel value={value} index={3}>
        Item four
        <Four/>
      </TabPanel>
      <TabPanel value={value} index={4}>
        Item five
        <Five/>
      </TabPanel>
    </Box>
    </div>




    <div id='MainJoin'>
    <button type="button" className="btn btn-light">Write a Post</button>
    <button type="button" className="btn btn-primary">Join Group</button>
    </div>





    </div>
    </>
  )
}
