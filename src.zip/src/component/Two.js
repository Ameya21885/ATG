import React from 'react';

export default function Two() {
  return (
    <div>
     <h1>Two</h1>
    </div>
  )
}
