import React from 'react';
import '../css/Main.css';
import one from '../img/Rectangle 5.png';
import article from '../img/Article.png';
import logo1 from '../img/logo1.png';
import VisibilityIcon from '@mui/icons-material/Visibility';
import ShareIcon from '@mui/icons-material/Share';
import two from '../img/Rectangle 6.png';
import education from '../img/Education.png';
import logo2 from '../img/logo2.png';
import three from '../img/Rectangle 7.png';
import meetup from '../img/Meetup.png';
import calender from '../img/calender.png';
import AddLocationAltIcon from '@mui/icons-material/AddLocationAlt';
import job from '../img/Job.png';
import bag from '../img/Job.png';
import bag1 from '../img/bag1.png';
import '../css/Header.css';

export default function One() {
  return (
    <> 
    <div>

{/* 1 */}
      <div className='Main'>
       <img src={one} alt='' className='a'/> <br/>
       <p className='MainOne'> 
       <img src={article} alt=''/>
       </p>

       <div className='MainH'> 
       <h4>What if famous brand had regular <br/> fonts? Meet
        RegulaBrands!
       </h4>
       <br/>
       <div className="dropdown">
  <a className="btnbtn-secondarydropdown-toggle-One" href="#" role="button" id="dropdownMenuLinkOne" data-bs-toggle="dropdown" aria-expanded="false">
    ...
  </a>

  <ul className="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <li><a className="dropdown-item" href="#">Edit</a></li>
    <li><a className="dropdown-item" href="#">Report</a></li>
    <li><a className="dropdown-item" href="#">option 3</a></li>
  </ul>
</div>
</div>

       <p className='paragraph'>I've worked in UX for the better part of a decade. 
        From now on, I plan to rei...
       </p>

       <div className='MainFooter'> 
       <img src={logo1} alt='' />
       <h4>Sarthak Karma</h4>
       <p className='MainFooterMiddle'><VisibilityIcon/> 1.4k views </p>
       <p className='MainFooterLast'> 
       <ShareIcon/>
       </p>
       </div>
      </div>

      
{/* 2 */}
<div className='Main'>
       <img src={two} alt='' className='a'/> <br/>
       <p className='MainOne'>
       <img src={education} alt='' /></p>

       <div className='MainH'> 
       <h4>What if famous brand had regular <br/> fonts? Meet
        RegulaBrands!
       </h4>
       <br/>
       <div className="dropdown">
  <a className="btnbtn-secondarydropdown-toggle-One" href="#" role="button" id="dropdownMenuLinkTwo" data-bs-toggle="dropdown" aria-expanded="false">
    ...
  </a>

  <ul className="dropdown-menu" aria-labelledby="dropdownMenuLink">
  <li><a className="dropdown-item" href="#">Edit</a></li>
    <li><a className="dropdown-item" href="#">Report</a></li>
    <li><a className="dropdown-item" href="#">option 3</a></li>
  </ul>
</div>
</div>

       <p className='paragraph'>I've worked in UX for the better part of a decade. 
        From now on, I plan to rei...
       </p>

       <div className='MainFooter'> 
       <img src={logo2} alt=''/>
       <h4>Sarthak Karma</h4>
       <p className='MainFooterMiddle'><VisibilityIcon/> 1.4k views </p>
       <p className='MainFooterLast'> 
       <ShareIcon/>
       </p>
       </div>
      </div>


{/* 3 */}
<div className='Main'>
       <img src={three} alt='' className='a'/> <br/>
       <p className='MainOne'> 
       <img src={meetup} alt=''/></p>

       <div className='MainH'> 
       <h4>What if famous brand had regular <br/> fonts? Meet
        RegulaBrands!
       </h4>
       <br/>
       <div className="dropdown">
  <a className="btnbtn-secondarydropdown-toggle-One" href="#" role="button" id="dropdownMenuLinkThree" data-bs-toggle="dropdown" aria-expanded="false">
    ...
  </a>

  <ul className="dropdown-menu" aria-labelledby="dropdownMenuLink">
  <li><a className="dropdown-item" href="#">Edit</a></li>
    <li><a className="dropdown-item" href="#">Report</a></li>
    <li><a className="dropdown-item" href="#">option 3</a></li>
  </ul>
</div>
</div>

       <div className='OneThree'>
         <p id='OneThreeA'><img src={calender} alt=''/>Fri,12Oct,2018</p>
         <p id='OneThreeB'><AddLocationAltIcon/> Ahmedabad, India</p>
       </div>

       <button type="button" className="btn btn-light" id='OneThreeButton'>Visit Website</button>

       <div className='MainFooter'> 
       <img src={logo1} alt=''/>
       <h4>Sarthak Karma</h4>
       <p className='MainFooterMiddle'><VisibilityIcon/> 1.4k views </p>
       <p className='MainFooterLast'> 
       <ShareIcon/>
       </p>
       </div>
      </div>


{/* 4 */}
<div className='Main'>
       <img src={bag} alt='' style={{position:'relative', right:'25ch'}}/> <br/>
       <p className='MainOne'> 
       <img src={meetup} alt=''/></p>

       <div className='MainH'> 
       <h4>What if famous brand had regular <br/> fonts? Meet
        RegulaBrands!
       </h4>
       <br/>
       <div className="dropdown">
  <a className="btnbtn-secondarydropdown-toggle-One" href="#" role="button" id="dropdownMenuLinkThree" data-bs-toggle="dropdown" aria-expanded="false">
    ...
  </a>

  <ul className="dropdown-menu" aria-labelledby="dropdownMenuLink">
  <li><a className="dropdown-item" href="#">Edit</a></li>
    <li><a className="dropdown-item" href="#">Report</a></li>
    <li><a className="dropdown-item" href="#">option 3</a></li>
  </ul>
</div>
</div>

       <div className='OneThree'>
         <p id='OneThreeA'><img src={bag1} alt=''/>Innovaccer Analytics Private Ltd.</p>
         <p id='OneThreeB'><AddLocationAltIcon/> Noida, India</p>
       </div>

       <button type="button" className="btn btn-light" id='OneThreeButton'>Apply on Timesjobs</button>

       <div className='MainFooter'> 
       <img src={logo1} alt=''/>
       <h4>Sarthak Karma</h4>
       <p className='MainFooterMiddle'><VisibilityIcon/> 1.4k views </p>
       <p className='MainFooterLast'> 
       <ShareIcon/>
       </p>
       </div>
      </div>

      


    </div>
    </>
  )
}
